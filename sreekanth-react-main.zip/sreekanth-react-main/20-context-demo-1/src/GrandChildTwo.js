import React from "react";

import ThemedComponent from "./ThemedComponent";

const GrandChildTwo = () => {
  return (
    <div className="grand-child-2">
      Grand Chile Two
      <ThemedComponent />
    </div>
  );
};

export default GrandChildTwo;
