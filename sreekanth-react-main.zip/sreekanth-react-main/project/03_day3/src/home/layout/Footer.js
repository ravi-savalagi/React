import React from "react";

const Footer = () => {
  return <h1 style={{ marginBottom: 30 }}>Footer</h1>;
};

export default Footer;
