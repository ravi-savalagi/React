import React from 'react'

function Category(props) {
  return (
    <tr>
      <td>
        <strong>{props.title}</strong>
      </td>
    </tr>
  )
}

export default Category
