import React from 'react'

function Form() {
  return (
    <form>
      <input type='search' placeholder='Search...' />
      <br />
      <input type='checkbox' /> &nbsp;Only show products in stock
    </form>
  )
}

export default Form
