import React from "react";

const GrandChildOne = () => {
  return <div className="grand-child-1">Grand Chile One</div>;
};

export default GrandChildOne;
