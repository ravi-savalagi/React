import React from 'react'

function AboutUs() {
  return <h1>About Us</h1>
}

export default AboutUs
