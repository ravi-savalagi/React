import React from 'react'

function Privacy() {
  return <h1>Privacy</h1>
}

export default Privacy
