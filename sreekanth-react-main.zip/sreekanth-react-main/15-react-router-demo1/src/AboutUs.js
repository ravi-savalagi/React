import React from 'react'

function AboutUs() {
  return (
    <div>
      <h1>About Us</h1>
    </div>
  )
}

export default AboutUs
