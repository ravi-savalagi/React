import React from 'react'

function Form() {
  return (
    <form>
      <input type='text' />
    </form>
  )
}

export default Form
