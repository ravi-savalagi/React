function Display() {
  return <h1>Input value: </h1>
}

export default Display
